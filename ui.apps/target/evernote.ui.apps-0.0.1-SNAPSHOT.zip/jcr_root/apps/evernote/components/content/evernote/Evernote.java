package apps.evernoteintegration.components.content.evernote;
import com.adobe.cq.sightly.WCMUse;

public class Evernote extends WCMUse {

	
	@Override
    public void activate() throws Exception {
    }
	
	
}
